-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2024 at 09:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `train ticket management system`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `Train_name` varchar(20) NOT NULL,
  `Bussiness_class` int(2) NOT NULL,
  `First_class` int(2) NOT NULL,
  `Cabin` int(2) NOT NULL,
  `Economy` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`Train_name`, `Bussiness_class`, `First_class`, `Cabin`, `Economy`) VALUES
('Dhaka Express', 30, 30, 40, 50),
('Fast Travel', 50, 50, 50, 150),
('Golden Express', 20, 25, 25, 30),
('Mid Night', 50, 50, 50, 100),
('Mid night', 30, 20, 10, 140),
('MoonShine Express', 20, 30, 25, 45),
('Royal Express', 10, 20, 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fare`
--

CREATE TABLE `fare` (
  `Price` int(20) NOT NULL,
  `Train_ID` varchar(20) NOT NULL,
  `Class` varchar(20) NOT NULL,
  `Destination` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fare`
--

INSERT INTO `fare` (`Price`, `Train_ID`, `Class`, `Destination`) VALUES
(10, ' K9', 'Economy', 'Mawa'),
(20, ' K9', 'First_class', 'Mawa'),
(30, ' K9', 'Cabin', 'Mawa'),
(40, ' K9', 'Bussiness_class', 'Mawa'),
(200, 'AE88', 'Economy', 'Cox\'s Bazar'),
(250, 'AE88', 'First_class', 'Cox\'s Bazar'),
(300, 'AE88', 'Cabin', 'Cox\'s Bazar'),
(400, 'AE88', 'Bussiness_class', 'Cox\'s Bazar'),
(200, 'A455', 'Economy', 'Rangpur'),
(230, 'A455', 'Bussiness_class', 'Rangpur'),
(250, 'A455', 'First_class', 'Rangpur'),
(350, 'A455', 'Cabin', 'Rangpur'),
(450, 'A947', 'Economy', 'Rajshahi'),
(500, 'A947', 'First_class', 'Rajshahi'),
(550, 'A947', 'Cabin', 'Rajshahi'),
(600, 'A947', 'Bussiness_class', 'Rajshahi'),
(50, 'I77G', 'Economy', 'Mawa'),
(70, 'I77G', 'First_class', 'Mawa'),
(80, 'I77G', 'Cabin', 'Mawa'),
(100, 'I77G', 'Bussiness_class', 'Mawa'),
(230, 'F161', 'Economy', 'Khulna'),
(280, 'F161', 'First_class', 'Khulna'),
(320, 'F161', 'Cabin', 'Khulna'),
(400, 'F161', 'Bussiness_class', 'Khulna'),
(350, 'M88', 'Economy', 'Sylhet'),
(400, 'M88', 'First_class', 'Sylhet'),
(450, 'M88', 'Cabin', 'Sylhet'),
(500, 'M88', 'Bussiness_class', 'Sylhet'),
(200, 'H11', 'Economy', 'Barishal'),
(250, 'H11', 'First_class', 'Barishal'),
(350, 'H11', 'Cabin', 'Barishal'),
(400, 'H11', 'Bussiness_class', 'Barishal'),
(1000, 'H12', 'Bussiness_class', 'Rangpur'),
(550, 'H12', 'First_class', 'Rangpur'),
(650, 'H12', 'Cabin', 'Rangpur');

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `Passenger_ID` varchar(20) NOT NULL,
  `Passenger_name` varchar(200) NOT NULL,
  `Number` int(11) NOT NULL,
  `Passenger age` int(3) NOT NULL,
  `Gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`Passenger_ID`, `Passenger_name`, `Number`, `Passenger age`, `Gender`) VALUES
('12101025', 'Jhumur Akter', 1315060129, 23, 'Female'),
('140303026', 'Kasim Murharjee', 1615040856, 19, 'Male'),
('15102030', 'Ruik Kasimoto', 1895402030, 24, 'Male'),
('19101052', 'Ayesha Sheikh', 1810102065, 25, 'Female'),
('20101028', 'Shara', 1234567879, 20, 'Female'),
('20101065', 'Sharifa Karim', 1615454689, 18, 'Female'),
('20201038', 'Towhidul Islam', 1234567894, 23, 'Male'),
('22101028', 'Umma Salma', 1234565789, 21, 'Male'),
('22101031', 'Mussarat Karim', 1235468790, 20, 'Female'),
('22101038', 'Yeamin Islam', 1234567891, 22, 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Transaction_ID` int(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Payment_type` varchar(50) NOT NULL,
  `Passenger_ID` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Transaction_ID`, `Price`, `Payment_type`, `Passenger_ID`) VALUES
(1101, 200, 'Cash', '12101025'),
(1102, 500, 'Card', '15102030'),
(1103, 200, 'Cash', '19101052'),
(1104, 400, 'Cash', '20101028'),
(1105, 400, 'Cash', '20101065'),
(1106, 1000, 'Card', '20201038'),
(1107, 80, 'Card', '22101028'),
(1108, 70, 'Cash', '22101031'),
(1109, 30, 'Card', '22101038'),
(1110, 400, 'Cash', '140303026');

-- --------------------------------------------------------

--
-- Table structure for table `refund`
--

CREATE TABLE `refund` (
  `Refund_ID` varchar(20) NOT NULL,
  `Ticket_ID` varchar(20) NOT NULL,
  `Payment_ID` int(20) NOT NULL,
  `Passenger_ID` varchar(20) NOT NULL,
  `Reason` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `refund`
--

INSERT INTO `refund` (`Refund_ID`, `Ticket_ID`, `Payment_ID`, `Passenger_ID`, `Reason`) VALUES
('506010', '10101101', 1101, '12101025', 'N/A'),
('506011', '10101104', 1104, '20101028', 'Time Mismatch'),
('506023', '10101106', 1106, '20201038', 'Date  Change');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `Route_no` varchar(20) NOT NULL,
  `Origin` varchar(20) NOT NULL,
  `Stoppage1` varchar(20) NOT NULL,
  `Stoppage2` varchar(20) NOT NULL,
  `Stoppage3` varchar(20) NOT NULL,
  `Stoppage4` varchar(20) NOT NULL,
  `Destination` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`Route_no`, `Origin`, `Stoppage1`, `Stoppage2`, `Stoppage3`, `Stoppage4`, `Destination`) VALUES
('007', 'Kamalapur', 'Tejgaon', 'Uttara', 'Gandaria', 'Keraniganj', 'Mawa'),
('01', 'Dhaka', 'Narayanganj', 'Agatala', 'Cumilla', 'Chattogram', 'Cox\'s Bazar'),
('02', 'Dhaka', 'Savar', 'Manikganj', 'Tangail', 'Sirajganj', 'Rajshahi'),
('03', 'Dhaka', 'Narsingdi', 'Kishoreganj', 'Mymensingh', 'Netrokona', 'Sylhet'),
('04', 'Dhaka', 'Bhanga', 'Faridpur', 'Narail', 'Jesore', 'Khulna'),
('05', 'Dhaka', 'Savar', 'Tangail', 'Bogura', 'Dinajpur', 'Rangpur'),
('06', 'Narayanganj', 'Madaripur', 'Tekerhat', 'Gopalganj', 'Wazipur', 'Barishal');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `Train_name` varchar(20) NOT NULL,
  `Train_ID` varchar(20) NOT NULL,
  `Destination` varchar(20) NOT NULL,
  `Route_no` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`Date`, `Time`, `Train_name`, `Train_ID`, `Destination`, `Route_no`) VALUES
('2024-05-07', '03:30:00', 'Golden Express', 'I77G', 'Mawa', '007'),
('2024-05-07', '04:30:00', 'Dhaka Express', ' K9', 'Mawa', '007'),
('2024-05-07', '05:30:00', 'Fast Travel', 'AE88', 'Cox\'s Bazar', '01'),
('2024-05-08', '14:30:00', 'Fast Travel', 'AE88', 'Cox\'s Bazar', '01'),
('2024-05-08', '15:30:00', 'Mid night', 'F161', 'Khulna', '04'),
('2024-05-08', '16:30:00', 'Royal Express', 'H12', 'Rangpur', '05'),
('2024-05-09', '04:30:00', 'Golden Express', 'I77G', 'Mawa', '007'),
('2024-05-09', '04:30:00', 'Royal Express', 'H11', 'Barishal', '06'),
('2024-05-10', '05:30:00', 'Royal Express', 'H11', 'Barishal', '04'),
('2024-05-10', '03:30:00', 'Fast Travel', 'A947', 'Rajshahi', '02'),
('2024-05-10', '04:30:00', 'Fast Travel', 'A455', 'Rangpur', '05'),
('2024-05-10', '05:30:00', 'Royal Express', 'H12', 'Rangpur', '03'),
('2024-05-08', '06:30:00', 'MoonShine Express', 'M88', 'Sylhet', '03'),
('2024-05-07', '04:30:00', 'MoonShine Express', 'M88', 'Sylhet', '03');

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `Ticket_ID` varchar(20) NOT NULL,
  `Train_ID` varchar(20) NOT NULL,
  `Carraige_no` int(20) NOT NULL,
  `Seat_no` varchar(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Date & Time` datetime NOT NULL,
  `Boarding Time` time NOT NULL,
  `Origin` varchar(20) NOT NULL,
  `Destination` varchar(20) NOT NULL,
  `Passenger_name` varchar(200) NOT NULL,
  `Passenger_ID` varchar(20) NOT NULL,
  `Class` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`Ticket_ID`, `Train_ID`, `Carraige_no`, `Seat_no`, `Price`, `Date & Time`, `Boarding Time`, `Origin`, `Destination`, `Passenger_name`, `Passenger_ID`, `Class`) VALUES
('10101100', 'A455', 2, '40W', 200, '2024-05-10 04:30:00', '04:30:00', 'Dhaka', 'Rangpur', 'Jhumur Akter', '12101025', 'Economy'),
('10101101', 'A947', 3, '30S', 500, '2024-05-10 03:30:00', '03:30:00', 'Dhaka', 'Rajshahi', 'Ruik Kasimoto', '15102030', 'First_class'),
('10101102', 'AE88', 4, '10S', 200, '2024-05-08 14:30:00', '14:00:00', 'Dhaka', 'Cox\'s Bazar', 'Ayesha Sheikh', '19101052', 'Economy'),
('10101103', 'F161', 6, '10W', 400, '2024-05-08 15:30:00', '15:30:00', 'Dhaka', 'Khulna', 'Shara', '20101028', 'Bussiness_class'),
('10101104', 'H11', 3, '20W', 400, '2024-05-10 05:30:00', '05:30:00', 'Dhaka', 'Barishal', 'Sharifa Karim', '20101065', 'Bussiness_class'),
('10101105', 'H12', 4, '10S', 1000, '2024-05-10 05:30:00', '05:30:00', 'Dhaka', 'Rangpur', 'Towhidul Islam', '20201038', 'Bussiness_class'),
('10101106', 'I77G', 1, '22W', 80, '2024-05-07 03:30:00', '03:30:00', 'Dhaka', 'Mawa', 'Umma Salma', '22101028', 'Cabin'),
('10101107', 'I77G', 5, '26S', 70, '2024-05-07 03:30:00', '03:30:00', 'Dhaka', 'Mawa', 'Mussarat Karim', '22101031', 'First_class'),
('10101108', ' K9', 6, '25S', 30, '2024-05-07 04:30:00', '04:30:00', 'Dhaka', 'Mawa', 'Yeamin Islam', '22101038', 'Cabin'),
('10101109', 'M88', 7, '50W', 400, '2024-05-08 06:30:00', '06:30:00', 'Dhaka', 'Mawa', 'Kasim Murharjee', '140303026', 'First_class');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_counter`
--

CREATE TABLE `ticket_counter` (
  `Ticket_ID` varchar(20) NOT NULL,
  `Payment_type` varchar(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Date&Time` datetime NOT NULL,
  `Counter_no` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket_counter`
--

INSERT INTO `ticket_counter` (`Ticket_ID`, `Payment_type`, `Price`, `Date&Time`, `Counter_no`) VALUES
('10101100', 'Cash', 200, '2024-04-27 20:33:56', 1),
('10101101', 'Card', 500, '2024-04-27 20:33:56', 2),
('10101102', 'Cash', 200, '2024-04-27 20:33:56', 1),
('10101103', 'Cash', 400, '2024-04-27 20:33:56', 1),
('10101104', 'Cash', 400, '2024-04-27 20:33:56', 3),
('10101105', 'Card', 1000, '2024-04-27 20:33:56', 4),
('10101106', 'Card', 80, '2024-04-27 20:33:56', 4),
('10101107', 'Cash', 70, '2024-04-27 20:33:56', 2),
('10101108', 'Card', 30, '2024-04-27 20:33:56', 5),
('10101109', 'Cash', 400, '2024-04-27 20:33:56', 2);

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `Train_ID` varchar(20) NOT NULL,
  `Train_name` varchar(20) NOT NULL,
  `Number_of_carriage` int(20) NOT NULL,
  `Seat_count` int(20) NOT NULL,
  `Train_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`Train_ID`, `Train_name`, `Number_of_carriage`, `Seat_count`, `Train_type`) VALUES
(' K9', 'Dhaka Express', 5, 150, 'Inter city'),
('A455', 'Fast Travel', 12, 300, 'Regional'),
('A947', 'Fast Travel', 12, 300, 'Regional'),
('AE88', 'Fast Travel', 10, 300, 'Regional'),
('F160', 'Mid Night', 13, 250, 'Regional'),
('F161', 'Mid night', 9, 200, 'Regional'),
('H11', 'Royal Express', 6, 40, 'Regional'),
('H12', 'Royal Express', 4, 40, 'Regional'),
('I77G', 'Golden Express', 5, 100, 'Inter city'),
('M88', 'MoonShine Express', 8, 120, 'Regional');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD KEY `Train_name` (`Train_name`);

--
-- Indexes for table `fare`
--
ALTER TABLE `fare`
  ADD KEY `Price` (`Price`);

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`Passenger_ID`),
  ADD UNIQUE KEY `Passenger_name` (`Passenger_name`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Transaction_ID`),
  ADD KEY `Payment_type` (`Payment_type`),
  ADD KEY `Passenger_ID` (`Passenger_ID`),
  ADD KEY `Price` (`Price`);

--
-- Indexes for table `refund`
--
ALTER TABLE `refund`
  ADD PRIMARY KEY (`Refund_ID`),
  ADD KEY `Passenger_ID` (`Passenger_ID`),
  ADD KEY `Payment_ID` (`Payment_ID`),
  ADD KEY `Ticket_ID` (`Ticket_ID`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`Route_no`),
  ADD KEY `Origin` (`Origin`),
  ADD KEY `Destination` (`Destination`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD KEY `Train_name` (`Train_name`),
  ADD KEY `Train_ID` (`Train_ID`),
  ADD KEY `Route_no` (`Route_no`),
  ADD KEY `Destination` (`Destination`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`Ticket_ID`),
  ADD KEY `Train_ID` (`Train_ID`),
  ADD KEY `Passenger_ID` (`Passenger_ID`),
  ADD KEY `Passenger_name` (`Passenger_name`),
  ADD KEY `Origin` (`Origin`),
  ADD KEY `Destination` (`Destination`),
  ADD KEY `Price` (`Price`);

--
-- Indexes for table `ticket_counter`
--
ALTER TABLE `ticket_counter`
  ADD PRIMARY KEY (`Ticket_ID`),
  ADD KEY `Payment_type` (`Payment_type`),
  ADD KEY `Price` (`Price`);

--
-- Indexes for table `train`
--
ALTER TABLE `train`
  ADD PRIMARY KEY (`Train_ID`),
  ADD KEY `Train_name` (`Train_name`),
  ADD KEY `Seat_count` (`Seat_count`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `class`
--
ALTER TABLE `class`
  ADD CONSTRAINT `class_ibfk_1` FOREIGN KEY (`Train_name`) REFERENCES `train` (`Train_name`);

--
-- Constraints for table `fare`
--
ALTER TABLE `fare`
  ADD CONSTRAINT `fare_ibfk_1` FOREIGN KEY (`Train_ID`) REFERENCES `train` (`Train_ID`),
  ADD CONSTRAINT `fare_ibfk_2` FOREIGN KEY (`Destination`) REFERENCES `route` (`Destination`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`Passenger_ID`) REFERENCES `passenger` (`Passenger_ID`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`Passenger_ID`) REFERENCES `passenger` (`Passenger_ID`),
  ADD CONSTRAINT `payment_ibfk_3` FOREIGN KEY (`Price`) REFERENCES `fare` (`Price`);

--
-- Constraints for table `refund`
--
ALTER TABLE `refund`
  ADD CONSTRAINT `refund_ibfk_1` FOREIGN KEY (`Passenger_ID`) REFERENCES `passenger` (`Passenger_ID`),
  ADD CONSTRAINT `refund_ibfk_2` FOREIGN KEY (`Payment_ID`) REFERENCES `payment` (`Transaction_ID`),
  ADD CONSTRAINT `refund_ibfk_3` FOREIGN KEY (`Ticket_ID`) REFERENCES `ticket` (`Ticket_ID`);

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`Train_name`) REFERENCES `train` (`Train_name`),
  ADD CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`Train_ID`) REFERENCES `train` (`Train_ID`),
  ADD CONSTRAINT `schedule_ibfk_4` FOREIGN KEY (`Route_no`) REFERENCES `route` (`Route_no`),
  ADD CONSTRAINT `schedule_ibfk_5` FOREIGN KEY (`Destination`) REFERENCES `route` (`Destination`);

--
-- Constraints for table `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`Train_ID`) REFERENCES `train` (`Train_ID`),
  ADD CONSTRAINT `ticket_ibfk_2` FOREIGN KEY (`Passenger_ID`) REFERENCES `passenger` (`Passenger_ID`),
  ADD CONSTRAINT `ticket_ibfk_3` FOREIGN KEY (`Passenger_name`) REFERENCES `passenger` (`Passenger_name`),
  ADD CONSTRAINT `ticket_ibfk_5` FOREIGN KEY (`Origin`) REFERENCES `route` (`Origin`),
  ADD CONSTRAINT `ticket_ibfk_6` FOREIGN KEY (`Destination`) REFERENCES `route` (`Destination`),
  ADD CONSTRAINT `ticket_ibfk_7` FOREIGN KEY (`Price`) REFERENCES `payment` (`Price`);

--
-- Constraints for table `ticket_counter`
--
ALTER TABLE `ticket_counter`
  ADD CONSTRAINT `ticket_counter_ibfk_4` FOREIGN KEY (`Payment_type`) REFERENCES `payment` (`Payment_type`),
  ADD CONSTRAINT `ticket_counter_ibfk_5` FOREIGN KEY (`Price`) REFERENCES `payment` (`Price`),
  ADD CONSTRAINT `ticket_counter_ibfk_6` FOREIGN KEY (`Ticket_ID`) REFERENCES `ticket` (`Ticket_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
