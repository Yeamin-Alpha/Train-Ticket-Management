package application;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import library.CheckOutRecord;
import library.CheckedOutException;
import library.InvalidItemException;
import library.InvalidMemberException;
import library.Item;
import library.Member;

public class CheckoutsController {

   @FXML
   private TextField itemIDField, memberIDField;

   @FXML
   private TextArea textarea;

   @FXML
   void checkSearch(ActionEvent event) {
      textarea.clear();
      String memberId = memberIDField.getText();
      String itemId = itemIDField.getText();

      try {
         if (!(memberId.isEmpty() || memberId.isBlank())) {// de-morgan
            Member member = App.library.findMember(memberId);
            showCheckOutRecords(member.getChekOutRecords());
         }

         if (!(itemId.isEmpty() || itemId.isBlank())) {// de-morgan
            Item item = App.library.findItem(itemId);
            showCheckOutRecords(item.getCheckOutRecords());
         }

      } catch (InvalidMemberException | InvalidItemException e) {
         textarea.setText(e.getMessage());
      }
   }

   private void showCheckOutRecords(ArrayList<CheckOutRecord> records) {
      String data = "";

      if (!records.isEmpty()) {
         for (CheckOutRecord record : records) {
            data += record + "\n";
         }
         textarea.setText(data);
      } else {
         textarea.setText("Empty Checkout Record!");
      }
   }

   @FXML

   void checkin(ActionEvent event) {
      textarea.clear();
      String itemid = itemIDField.getText();
      try {
         App.library.checkIn(itemid);
         textarea.setText("Item " + itemid + " has been check in successfull.");
      } catch (InvalidItemException e) {
         textarea.setText(e.getMessage());
      }
   }

   @FXML
   void checkout(ActionEvent event) {
      textarea.clear();
      String itemid = itemIDField.getText();
      String memberid = memberIDField.getText();

      try {
         App.library.checkOut(itemid, memberid);
         textarea.setText("Item " + itemid + " successfully checked out by " + memberid);
      } catch (CheckedOutException | InvalidItemException | InvalidMemberException e) {
         textarea.setText(e.getMessage());
      }
   }

   @FXML
   void extendtime(ActionEvent event) throws CheckedOutException {
      textarea.clear();
      String id = itemIDField.getText();
      try {
         App.library.extendCheckOut(id);
         textarea.setText("Item " + id + " Extend time one week");
      } catch (InvalidItemException e) {
         textarea.setText(e.getMessage());
      }
   }
}
